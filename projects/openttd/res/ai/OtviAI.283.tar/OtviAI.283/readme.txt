This AI is part of a collection of test AI's written with the intention of training and improving our main AI: rondje (Rondje om de kerk). The collection currently features three AI's:

- OtviAI	: a passenger and mail carrying AI
- OtviCargo	: transports cargo by trucks
- OtviSubAI	: transport anything that has a subsidy
There's work going on for trains, trams and boats, but that's still very alpha.

OtviAI is the best optimized and largest of these three, as it quickly showed that subsidies don't come often enough to be a big player and are hard to get if there's someone else trying to get it as well. On top of that: the passenger subsidies are usually not the most profitable routes on the map. Any AI carrying cargo is a lost case if rondje is involved, so this AI is also featuring a reasonable number of TODO's :)

All our code is released under GPL v2, we already made our profit by winning the TJIP challenge ;-)

Comments and suggestions are always welcome, please send them to: rondjeomdekerk@konstapel.nl

